// choose file

import "package:flutter/material.dart";

void main() {
  runApp(new MyApp());
}

class First extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
/*routes:<String,WidgetBuilder> {
'/Screen1':(BuildContext context)=> Screen1(),
'/Screen2':(BuildContext context)=> Screen2(),

      

  } ,   */
      home: Scaffold(
        appBar: AppBar(
          title: Text("Demo"),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.all(26.0),
            children: <Widget>[
              new DrawerHeader(
                decoration: BoxDecoration(color: Colors.cyan),
                child: Text(
                  "Hello",
                  style: TextStyle(color: Colors.white, fontSize: 29.0),
                ),
              ),
              ListTile(
                leading: Icon(Icons.login),
                title: Text("Login"),
              ),
              ListTile(
                leading: Icon(Icons.account_circle),
                title: Text("Profile"),
              ),
              ListTile(
                leading: Icon(Icons.settings),
                title: Text("Settings"),
              ),
            ],
          ),
        ),
        body: Center(
          child: Container(
            padding: EdgeInsets.all(50.0),
            alignment: Alignment.center,
            color: Colors.blueAccent,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.network("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2QMkOyqwEyzvNAqP1imDsk-fwuFm0EWJlYQ&usqp=CAU"),
                Text(
                  "Welcome User",
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: Colors.white, fontSize: 35.0),
                ),
                Text(
                  "Showing Homepage",
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: Colors.white, fontSize: 24.0),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navigation',
      initialRoute: '/',
      routes: {
        '/': (context) => Screen1(),
        '/second': (context) => Screen2(),
      },
    );
  }
}

class Screen1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("screen1"),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.all(26.0),
            children: <Widget>[
              new DrawerHeader(
                decoration: BoxDecoration(color: Colors.cyan),
                child: Text(
                  "Hello",
                  style: TextStyle(color: Colors.white, fontSize: 29.0),
                ),
              ),
              ListTile(
                leading: Icon(Icons.login),
                title: Text("Login"),
              ),
              ListTile(
                leading: Icon(Icons.account_circle),
                title: Text("Profile"),
              ),
              ListTile(
                leading: Icon(Icons.settings),
                title: Text("Settings"),
              ),
            ],
          ),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.network("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsp2PkeGtfTkuba_5folbibb-2jpfRD9RKPQ&usqp=CAU"),
       Text(
     "Showing Homepage",
                textDirection: TextDirection.ltr,
                style: TextStyle(color: Colors.white, fontSize: 24.0),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/second');
                },
  child: Text("Press to go to next page"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Screen2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("screen2"),
      ),
      body: Center(                 
       child: Column(
mainAxisAlignment: MainAxisAlignment.center,
 children: <Widget>[
Row( 
children:<Widget>[
Expanded(
child:Text( 
"Here is a glimpse of your travel destination",
textDirection: TextDirection.ltr,
style: TextStyle(color:Colors.cyan, fontSize: 24.0),),),
Expanded( 
    
child:Image.network("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSV689KVRR8cBK69JeXRncjD35FhG1mi7LcpA&usqp=CAU"),),],),
       
 ElevatedButton(
 onPressed: () 
     {
Navigator.pop(context);
              },
 child: Text("Back to prev screen"),
            ),
          ],
        ),
      ),
    );
  }
}
